Crypto Marubozu 10M Scanner — Android Project

এই ZIP-এ আপনার HTML স্ক্যানারকে Android WebView অ্যাপে প্যাকেজ করার Android Studio source project আছে।
মূল Marubozu 10M LONG/SHORT নিয়ম রাখা হয়েছে। নতুন সিগন্যাল প্রথমবার শনাক্ত হলে ফোনে notification পাঠানোর ব্যবস্থা যোগ করা হয়েছে।

সীমাবদ্ধতা:
- ZIP-এ APK নয়, Android Studio source project আছে; এখানে APK build করা হয়নি।
- স্ক্যানিং অ্যাপ খোলা/চলমান থাকলে কাজ করবে। অ্যাপ বন্ধ বা ব্যাকগ্রাউন্ডে থামলে স্ক্যান বন্ধ হতে পারে।
- ইন্টারনেট, Binance API/WebSocket সংযোগ এবং notification permission প্রয়োজন।
- সিগন্যাল সম্ভাব্যতা; লাভের নিশ্চয়তা নয়।

APK বানানোর ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP extract করুন।
3. Android Studio > Open দিয়ে CryptoMarubozuAndroid ফোল্ডার খুলুন।
4. Gradle sync শেষ হতে দিন (JDK 17, Android SDK Platform 35 লাগতে পারে)।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
6. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ পাওয়া যাবে।
7. APK ফোনে install করে খুলুন, notification permission Allow করুন, তারপর স্ক্যান চালু করুন।
